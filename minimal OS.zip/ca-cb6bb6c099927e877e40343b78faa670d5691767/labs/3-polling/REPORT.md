## Code explanation:
This code is reading a character from input and displaying it. And it follows these steps:

1. It starts by reading the **Receiver Control Register (address: 0xffff0000)** and checking if a new character has been received by comparing the LSB with 1.

2. Once a character is received, the ASCII code of this character will be stored in the **Receiver Data Register (address: 0xffff0004)** and the LSB resets to 0.

3. In the transmitter side, the code waits for the **Transmitter Control Register (address: 0xffff0008)** to have the LSB sets equal to 1, which means it’s ready to send data.

4. Then, it writes the ASCII code of the character in the **Transmitter Data Register (address: 0xffff000c)**. While doing this, it sets the LSB to 0 to show that the transmitter is busy and then resets it to 1.

5. after each transmitted character, it sends a newline character to the **Transmitter Data Register (address: 0xffff000c)**.

While testing with different characters, the code worked as expected.
## Example: typing the character 'a':

When I type the character **'a'** on the keyboard, it follows the steps previously explained. The ASCII code is stored at the address **0xffff0004** with the value **0x00000061** in hexadecimal, which is equivalent to **97** in decimal. The character 'a' is then stored at the address **0xffff000c**, and the process returns to the next line.

## Code optimization:
To optimize the code i followed these rules:

* Load the addresses used during this code outside the loops.

* Instead of loading the transmitter control register and transmitter data register twice
for every use, we can simply load them once outside the loops and reuse them when its needed.

This will reduce the number of instructions by removing redundancy and the execution will be faster.

## Conclusion:
This lab gave us a good start in working with hardware, showing how to use registers for specific tasks such as displaying characters through memory-mapped I/O (MMIO).
