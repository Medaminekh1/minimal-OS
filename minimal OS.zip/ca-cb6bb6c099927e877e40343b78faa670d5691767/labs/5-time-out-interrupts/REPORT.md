# Purpose:
The goal of this lab is to learn how to handle interrupts and exceptions especially the timer
interrupts and how to use them.
# The time-out flag:
Here is a description of what I did in this part:

* Add a global time_out flag in the .data section to track the timeout status. It is
initialized to 0.

* Add the set_timer function that takes a delay in milliseconds as a parameter from the
register a0 and return nothing.

* Modify the functions **getc** and **putc** to check for timeout. It waits for 5 seconds if the
user does not input an integer, or nothing is printed at that time. The program leaves
these functions with the error code 4. This will make the program not be stuck forever.

* Adapt the main to handle the new error of time_out (code 4) and displays this
message if it is the case **“Timeout”**.

We use the error codes 1, 2, and 4 which are the powers of 2 so that we can easily be used
with the bitwise **ANDI** to check for the errors.

There aren’t a lot of changes in this version, that’s why it behaves as the previous one. This
test was made just to make sure the program still works, and it is.

# The timer tool
When I ran the Timer tool and stopped it at 2.07 seconds, I saw the value 2807 at the
address **0xffff0018**, which is not the same. Maybe cause the timer tool doesn’t use
milliseconds but another unit of time.

I modified the main program to read the timer value from the timer tool right after the user
inputs an integer. I stored the timer value in a register and printed a message like this:
**'You entered the number 10 at 1241 milliseconds.'**

The code worked as expected in all my tests.

# Exceptions, interrupts, Control and Status Registers
I used the function csrrw to copy the value of time from the saved register to the uscratch
which will be used to store temporary the time in case of interruption. I tested the code and it
worked for example for 1396 milliseconds I can see **0x000000574** in uscratch.

# First exception handler, numeric code of timer interrupt
In this part, I developed the exception_handler that runs to manage unexpected events such
as an interrupt. What it does:

* **Save the Program's State:** like saving the stack and registers so the program can
continue after the exception is resolved.

* **Handle the Event:** read the Control and Status Registers (CSRs) and print their
values.

* **Return to the Program:** After the issue is resolved, the program continues execution.
I also modified the set_timer to enable the timer interrupt after 5 seconds and the main to
enable this interrupt.

When I ran the program, it worked as expected, and I got these values:

* **ustatus:** 0x00000010: the user mode interrupt is enabled

* **uie:** 0x00000010: the timer interrupt is enabled

* **utvec:** 0x00400000: the starting address of the exception handler

* **uscratch:** 0x7fffefbc

* **uepc:** 0x00400184: the address where the program should resume after handling the
exception.

* **ucause:** 0x80000004: the cause of the interrupt

Before the interrupt occurred the program was executing the instruction with address
0x00400184 which correspond to **“beq zero,t4,putc_wait”**.

The timer interrupt code is 0x4 which is the lower bits of the interrupt.
To distinguish between an interrupt and an exception we can check the MSB of ucause if it is
1 then it is an interrupt else it is an exception.

# Using timer interrupts to set the time-out flag
This part works as expected when the timer tool exceeds 5 seconds the message timeout
will be displayed.

**Bonus question:** if we don’t use this order it can cause a conflict, a timeout from the previous
operation might still be active. In this case the program think that a timeout occurred for the
current operation. So with this order we avoid interfere.
