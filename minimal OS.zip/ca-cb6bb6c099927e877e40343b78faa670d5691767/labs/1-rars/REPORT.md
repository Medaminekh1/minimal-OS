# Launch RARS, settings, help, registers
During the initial launch of RARS there are registers that contain value 0 and others has positive value cause these values are presented as unsigned hexadecimal. In other side there is the program counter PC that has the value 0x00400000.
# Unsigned and signed integers
## Coding
To initialize the value of the register t0 I added the content of the register x0 which is always zero with the value 1.
## Assembling
The address of the first instruction is 0x00400000 which is the same on the PC. So, it’s obvious that the PC contains the address of the first instruction to execute.
## Simulation
After executing it step by step the register t0 changed its current value to 1 which corresponds to the initial value we chose so the code works as expected.
## Left shifts as a way to multiply by powers of 2
The value stored in t1 is 2 where we multiply the value of the register t0 which is 1 by 2 using the shift left with one position. We can use this for other multiplications, such as by 3.
## Overflows
In the second addition the register t2 starts showing negative values even if the two added values are positive and this is because we exceed the range can be
represented by 32 bits, which is an overflow. So, in this case the register showed the -67108864 which equivalent to 4227858432 if we use unsigned number and it is double the previous value of the register. If we add again the value it will give us a result that is not related to previous ones.
## Sign and magnitude or 2's complement
When there is an overflow the sign and magnitude doesn’t change the sign of the result it just shows incorrect result unlike the 2’s complement and of course I had the opposite sign in overflow so we can conclude that RARS uses 2’s complement.
## Modulo a power of 2
The idea was to use the bitwise AND with the lowest 7 bits of the number and set all higher bits to 0 and this gives us the remainder when dividing by 128. But this method doesn’t work with negative value cause in 2’s complements the highest bit is set to 1. So to compute the modulo 2^n, where n in [1,31] , we use the bitwise AND between the number and (2^n-1)
## Underflow
The smallest possible number is -2^31. If we add -1 to this number, it will give us the largest number.
## Right shifts as a way to divide by powers of 2
Srli of a negative number gives us a positive number while srai gives us a negative number cause simply when we use srli the msb entered is zero always while with srai it depends from your value
# Controlling overflows
For the unsigned addition, if the value of the operand register is higher than the result then this is an overflow. And for unsigned subtraction if the first operand register is higher than the second operand this is an overflow. For the signed addition if both operands are in same sign but the result is with the opposite sign then we have an overflow. For the signed subtraction if both operands have different signs and the result is also different from the first operand then we have an overflow.
# Floating point numbers
* Using Floating Point Representation tool we can always represent accurately the finite number like 1/2 unlike the infinte number like 1/3. 
* The computed result of (ft2 + ft3) - ft3 is not ft2 but instead 0 because ft2 is too small to affect the sum ft2 + ft
* We can divide a positive value with zero to get an infini, a negative value with zero to get -infini and zero with zero to get NaN.
