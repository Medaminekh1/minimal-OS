# Program explanation:
This program allows users to enter a character and display it back until he enters the character Q. It has two primary functions, the ‘getc’ to read a character from the keyboard and ‘putc’ to display the character on the console. So, it starts with asking for a character then it reads this character store its ASCII code and uses it to display the character on the console. This loop continues until the user enters the character ‘Q’ then the program exits.
This code uses three syscalls, this first is ReadChar and used to read the input. The second one is PrintChar used to display this input on console. And the last one is PrintString to display a message on console.

# How to use syscalls:
* Load the service number into register a7.
* If the syscall need a paramter, we use the register a0 to load it.
* execute the call by using 'ecall'.
* Get the result (if there is an output), it will be saved in a0 by default.

# Print the ASCII code of the character:
I used the syscall number 1 (PrintInt) to print an integer which is the ASCII code of the character and the output of the function 'getc'. 
So my function called puti it starts by creating a stack frame and save the return address register on the stack. Then load the service 1 (that will print an integer) into register a7 and execute it . And finally we restore ra from the stack and deallocate the stack frame to free up the memory space. 
