# Purpose :
The goal of this lab is to create a mini OS that can executes two user tasks with infinte loop
and handles switching between them.

## User tasks
This is the part to create the tasks. We have two tasks “taskA” and “taskB”. The first one
prints 'A' at every 10007 increment, and the second one prints &#39;B&#39; at every 30011 increments.
I used the syscall **“printchar”** to display these characters.

Both tasks function as expected, running in infinite loops to display their corresponding
outputs.

## Understanding the starting point of the mini-OS
* The ucause contains the information about what cause the trap and if there is an
interrupt the MSB is 1 else it will be 0. we know also that rars uses 2’s complement so
if the MSB is 1 which is an interrupt the value will be negative that’s why we compare
it to zero and branch to interrupt if it is the case.
* This program treats 3 cases after the execption
    * Continue executing if the cause was an interrupt
    * Skip the Cause of Interruption for exceptions that can cause an infinite loop by
using the code 3 for breakpoint and 8 for environment call.
    * Terminate the Program Immediately when the exception is not recoverable
and it prints error message.

* The program calculates the address of the corresponding ISR by multiplying the
interrupt number by 4 ( the number of bytes for each word) and add it to the base
address of ISR to find the corresponding one.

## Call a user task, test an exception
* After adding the instruction to call taskA and debuging the code the program
executes as excpetcted it shows the letter A in infinite loop which shows that the well
functionality of the code
* Adding 2 to the the address of taskA will create a misaligned address cause its not a
multiple of 4 and jumbing to this address will lead the system to show the error
**“Exception 0 (instruction address misaligned) occurred Unrecoverable,
aborting”** and the program exits
* I set a breakpoint in the instruction that caused the error jalr and I got these different
values before and after I enter the exception:

**Before:**

* Status: 1 which indicates that the interrupt is enabled
* utvec: 0x00400000 is where the execption handler is located
* uepc: 0
* ucause: 0 cause the code for instruction address misaligned is 0.

**After:**

* Status: Updated to 16.
* utvec: Remained unchanged.
* uepc: Updated to the address of the faulty jalr instruction (0x0040014a).
* ucause: Remained 0.

## Add a timer ISR
* The timer ISR prints the character **'*'** every 100 milliseconds.
* Configures a timer to trigger an interrupt every 100 milliseconds.
* Saves the current task's state (Task A or Task B).
* Executes the Timer ISR.
* Restores and resumes the previously paused task.

I test with both taskA and taskB to make sure the program works as expected and it
is.

## Context switch
the registers that constitute the context of a running task are:

* General-Purpose Registers
    * **From:** CPU register file.
    * **To:** Saved to memory (kernel stack or task context structure).
* Floating-Point Registers
    * **From:** CPU floating-point register file.
    * **To:** Saved to memory.
* Status and Control Registers
    * **From:** Read from CSR registers.
    * **To:** Saved to memory (kernel stack or task context structure).
* The program counter
    * **From:** Retrieved from the CSR like uepc.
    * **To:** Saved to memory (kernel stack or task context structure).
* Stack pointer 
    * **From:** General-purpose register.
    * **To:** Saved to memory (kernel stack or task context structure).

**Used:**

* **taskA_stack,taskB_stack:** to separate stack memory for each task.
* **taskA_uepc, taskB_uepc:** to save the program counter for each task.
* **current_task:** to check which task is running (0 for taskA and 1 for taskB).

The new timer ISR is doing these steps:

* Check which task is running.
* Save the Current Task's Context.
* Switch to the other task by updating the current_task variable.
* Restore the new task's context.
* Set a timer for the next task switch.

In main:

* Initialize the necessary data for each task.
* Start with the taskB by default.

After several tests, I made sure that this program works as expected.

## Relaxing the constraints
1/ Use an array of stacks and an array of program counters, where each task will
have its own dedicated data. The initialization of the stack pointer and the starting
address for each task will be done using a loop, and the current_task variable will
range from 0 to 7 to track which task is currently running. The context-switching code
will be updated to save and restore the state for any of the 8 tasks.

2/ Add a task_state array to check if a task has terminated or not. Each task's state is
initially set to 1, and when a task finishes, it changes its state to 0. The scheduler will
only select tasks with a state of 1 for execution and skip those with a state of 0. When
no tasks with state 1 remain, the program will exit.

3/ First, I will let the user choose an action, either **'Start task'** or **'Terminate Task'** by inputting their choice using the keyboard. Based on their selection, I will display the list of tasks available for the chosen action. For example, if the user selects
**'Terminate task'** I will show the tasks that are currently running and can be
terminated. Then, the user can input their choice of task, and the program will update
the task_state array to make sure that only valid tasks are displayed for each action.
