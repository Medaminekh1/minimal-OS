# Purpose:
The objective of this lab is to use the Memory-Mapped Input/Output (MMIO) to read integers
entered by the user, check for errors and display it. This involved modifying and adding
labels to use MMIO instead of using system calls.
# Labels:
## Getc:
This function used to read the entered character. But instead of syscall the user can input the character thanks to Keyboard and Display MMIO simulator. I used two registers for this case:

* The Receiver Control Register to check if input was available.

* The Receiver Data Register to read the character.

This new label works correctly. When characters are entered in the Keyboard and Display
MMIO simulator, they are displayed in messages.
## Putc:
This function is used to display the entered character in the simulator. This is works with
these registers:

* The Transmitter Control Register to verify if the transmitter was ready.

* The Transmitter Data Register to send the character.

This new label works as expected. Characters entered are displayed now in the Keyboard
and Display MMIO simulator.

## Print_String
This function prints a NUL-terminated character string stored in memory. It will be using to
print the messages in the simulator. These are the steps:

* Read characters one by one.

* Stop when it finds the end of the string.

* Use putc to display each character.

This function works as expected and it shows messages in the simulator.

## d2i
This function takes the ASCII code of the entered integer and converts it to a decimal integer.
If the entered character isn’t integer, it returns an error. These are the steps:

* Check if the ASCII code of the entered character is between '0' and '9'.

* If not, it gives an error.

* Else it converts this ASCII code to a decimal integer

## Geti
This function reads the whole integer and checks for different error such as not a digit and
also overflow by comparing the new value after a multiplication by 10 and addition with the
old value. If the new value becomes smaller than the old one this is an obvious overflow.

## Puti

This function used to display the number one digit at a time in the Keyboard and Display
MMIO simulator. These are the steps:


* Find the last digit of the number.

* Remove it by dividing it by 10.

* Repeat until all digits are done.

## main
The new main handles every possible error and show error messages based on what went
wrong. What the new program does:

* Ask the user for input with this message **“Please enter an unsigned integer
followed by newline (0 to quit)”**

* Once the user enters an input.

* Check if the input is a digit: if it is not this error message is displayed **“The
character you entered is not a digit!”**

* Check for overflow: if the integer exceeds the range this error message is
displayed **“The integer you entered is too large to fit in 32 bits!”**

* Print the integer

* Loop again until 0 in entered to exit.

# Conclusion
After these modifications, the program can now read input and display output directly using
the Keyboard and Display MMIO simulator, without using syscalls. All functions work as
expected and meet all the lab requirements
